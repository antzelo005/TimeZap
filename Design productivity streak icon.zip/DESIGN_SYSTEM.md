# TimeZap Design System & Icon Package

Complete professional SVG icon system and UI asset package for TimeZap productivity application.

## Overview

TimeZap is a minimal task and habit management system focused on productivity, consistency, fast interactions, low cognitive load, and clean design. This design system provides all necessary visual assets for Android, iOS, and Web platforms using React Native.

## Design Philosophy

- **Modern**: Contemporary visual language aligned with 2024-2026 design trends
- **Minimal**: Clean, uncluttered design with focus on essential elements
- **Premium**: Professional SaaS-grade quality
- **Productivity-focused**: Designed to enhance user focus and efficiency
- **Dark-mode first**: Optimized for #081A33 primary background
- **Consistent**: Unified visual language across all components

## Color Palette

```
Primary Background: #081A33 (Dark Navy)
Accent Blue:        #4D8DFF
Accent Yellow:      #FFC93C
White:              #FFFFFF
```

### Usage Guidelines

- **Dark Navy (#081A33)**: Primary app background, navigation bars, cards
- **Accent Blue (#4D8DFF)**: Active states, CTAs, progress indicators, FAB
- **Accent Yellow (#FFC93C)**: Brand identity, logo, streak highlights
- **White (#FFFFFF)**: Text, icons, badges

## Icon System

### Base Specifications

- **Base Size**: 24x24 px (optimal for mobile touch targets)
- **Stroke Width**: 2px (consistent across all icons)
- **Corner Radius**: Rounded caps and joins
- **Format**: SVG Vector (infinitely scalable)
- **Active Color**: #4D8DFF (Accent Blue)
- **Inactive Color**: #FFFFFF with 60% opacity
- **Style**: Minimal stroke-based design

### Icon Inventory

#### 1. TimeZap Logo
**File**: `TimeZapLogo.tsx`

Stylized geometric lightning bolt representing speed and productivity.

**Props**:
- `size?: number` (default: 32)
- `className?: string`

**Usage**:
```tsx
import { TimeZapLogo } from './components/icons';

<TimeZapLogo size={32} />
```

**Design Notes**:
- Bright yellow (#FFC93C) primary color
- Geometric Z-shaped lightning bolt
- Gradient overlay for depth
- Works on dark backgrounds
- App icon and navigation bar ready

---

#### 2. Dashboard Icon
**File**: `DashboardIcon.tsx`

Analytics-inspired icon with ascending bars representing productivity metrics.

**Props**:
- `size?: number` (default: 24)
- `active?: boolean` (default: false)
- `className?: string`

**States**:
- Active: Blue (#4D8DFF) at 100% opacity
- Inactive: White at 60% opacity

---

#### 3. Tasks Icon
**File**: `TasksIcon.tsx`

Modern checklist icon with circular checkboxes and horizontal lines.

**Props**:
- `size?: number` (default: 24)
- `active?: boolean` (default: false)
- `className?: string`

**Design Notes**:
- Represents task completion states
- Two filled circles (completed tasks)
- One outlined circle (pending task)
- Rounded stroke caps for friendly appearance

---

#### 4. Habits Icon
**File**: `HabitsIcon.tsx`

Circular arrows representing repetition and consistency.

**Props**:
- `size?: number` (default: 24)
- `active?: boolean` (default: false)
- `className?: string`

**Design Notes**:
- Circular flow represents recurring habits
- Arrow tips indicate continuity
- Minimal design avoiding calendar clichés

---

#### 5. Calendar Icon
**File**: `CalendarIcon.tsx`

Clean calendar icon with minimal detail optimized for small sizes.

**Props**:
- `size?: number` (default: 24)
- `active?: boolean` (default: false)
- `className?: string`

**Design Notes**:
- Two hanger tabs at top
- Horizontal line separating header
- Three dots representing dates
- Minimal to remain clear at 24px

---

#### 6. Account Icon
**File**: `AccountIcon.tsx`

Simple user profile icon with head and shoulders silhouette.

**Props**:
- `size?: number` (default: 24)
- `active?: boolean` (default: false)
- `className?: string`

**Design Notes**:
- Circular head
- Curved shoulder line
- Minimal and universally recognizable

---

#### 7. Plus Icon
**File**: `PlusIcon.tsx`

Thick rounded plus sign for floating action buttons.

**Props**:
- `size?: number` (default: 24)
- `className?: string`

**Design Notes**:
- 3px stroke width for high visibility
- Rounded caps for friendly appearance
- Perfect centering
- White color (designed for blue FAB background)
- Available sizes: 16px, 24px, 32px, 48px

---

#### 8. Notification Icon
**File**: `NotificationIcon.tsx`

Notification bell with optional numbered badge support.

**Props**:
- `size?: number` (default: 24)
- `badgeCount?: number` (optional)
- `className?: string`

**Features**:
- Clean bell icon optimized for dark backgrounds
- Red notification badge (#EF4444)
- Badge displays 1-99, shows "99+" for higher values
- Badge auto-hides when count is 0 or undefined

**Usage**:
```tsx
<NotificationIcon size={24} badgeCount={5} />
```

---

#### 9. Streak Flame Icon ⭐
**File**: `StreakFlameIcon.tsx`

**Most Important Icon** - Flame and lightning hybrid representing productivity streaks.

**Props**:
- `size?: number` (default: 32)
- `streakNumber?: number` (optional)
- `active?: boolean` (default: true)
- `compact?: boolean` (default: false)
- `className?: string`

**Modes**:

**Badge Mode** (`compact={false}`):
- Circular badge with dark navy background
- Flame with yellow-to-orange gradient
- White lightning bolt integrated inside flame
- Streak number overlaid on badge
- Size: 32-64px recommended

**Compact Mode** (`compact={true}`):
- Standalone flame icon
- Streak number beside icon (not overlaid)
- Smaller footprint for headers
- Size: 24-32px recommended

**States**:

**Active** (`active={true}`):
- Bright yellow-to-orange flame gradient (#FFD700 → #FFA500 → #FF6B00)
- White lightning bolt
- High visibility and energy

**Inactive** (`active={false}`):
- Gray flame (#6B7280)
- No lightning bolt
- Represents 0 streak or paused streak

**Usage**:
```tsx
// Badge mode with streak number
<StreakFlameIcon size={48} streakNumber={12} active={true} />

// Compact mode for headers
<StreakFlameIcon size={24} streakNumber={12} active={true} compact={true} />

// Inactive state (0 streak)
<StreakFlameIcon size={48} streakNumber={0} active={false} />
```

**Design Notes**:
- Inspired by Duolingo streaks but more professional
- Emotional impact: achievement, consistency, momentum
- Recognizable at very small sizes (24px+)
- Gradient provides visual richness without complexity
- Lightning bolt adds energy and "zap" brand connection

---

## Component System

### Bottom Navigation
**File**: `BottomNavigation.tsx`

Complete bottom navigation bar with all navigation icons.

**Props**:
- `activeItem?: NavItem` ("dashboard" | "tasks" | "habits" | "calendar" | "account")
- `onItemClick?: (item: NavItem) => void`
- `className?: string`

**Features**:
- Consistent stroke width across all icons
- Active/inactive state management
- Safe area support for notched devices
- 80px height (20px taller than standard for premium feel)
- Dark navy background (#081A33)
- Smooth transitions

**Usage**:
```tsx
import BottomNavigation from './components/BottomNavigation';

<BottomNavigation 
  activeItem="tasks"
  onItemClick={(item) => navigate(item)}
/>
```

---

### Floating Action Button
**File**: `FloatingActionButton.tsx`

Material Design-inspired FAB with accent blue background.

**Props**:
- `onClick?: () => void`
- `size?: "small" | "medium" | "large"`
- `className?: string`

**Sizes**:
- Small: 48px (w-12 h-12)
- Medium: 56px (w-14 h-14) - **Recommended**
- Large: 64px (w-16 h-16)

**Features**:
- Accent blue background (#4D8DFF)
- White plus icon with thick strokes
- Elevated shadow (shadow-lg)
- Hover state (lighter blue)
- Active state (scale down)
- Smooth transitions

**Usage**:
```tsx
import FloatingActionButton from './components/FloatingActionButton';

<FloatingActionButton 
  size="medium"
  onClick={handleAddTask}
/>
```

---

## Dashboard UI Concepts

### Compact Streak Indicator

**Location**: Top-right corner of app header (similar to Duolingo)

**Design**:
- Compact flame icon with streak number beside it
- Small footprint (24-32px icon)
- Always visible for motivation
- Gray when streak = 0

**Implementation**:
```tsx
<div className="flex items-center gap-4">
  <StreakFlameIcon 
    size={24} 
    streakNumber={streak} 
    active={streak > 0} 
    compact={true} 
  />
  <NotificationIcon size={24} badgeCount={notifications} />
</div>
```

### Summary Cards

**Task Summary Card**:
- Shows today's task count
- Progress bar showing completion
- Clickable to navigate to Tasks screen
- Blue accent (#4D8DFF)

**Habit Summary Card**:
- Shows today's habit count
- Progress bar showing completion
- Clickable to navigate to Habits screen
- Yellow accent (#FFC93C)

**Design Pattern**:
- Glass-morphism style (white/5% background, backdrop-blur)
- Subtle border (white/10%)
- 2xl rounded corners (16px)
- Hover state (white/10% background)
- Smooth transitions

### Weekly Progress Visualization

**Design**:
- 7 day grid (Monday - Sunday)
- Square tiles with rounded corners
- Completed days: Blue background with checkmark
- Today: Yellow ring highlight
- Future/incomplete days: Gray background
- Interactive: tap to view day details

---

## React Native Integration

### Installation

All components are TypeScript React components using SVG. No external dependencies required beyond React.

### Import Pattern

```tsx
// Individual imports
import { TimeZapLogo, DashboardIcon, TasksIcon } from './components/icons';
import BottomNavigation from './components/BottomNavigation';
import FloatingActionButton from './components/FloatingActionButton';

// Usage
<TimeZapLogo size={32} />
<DashboardIcon size={24} active={true} />
<BottomNavigation activeItem="dashboard" />
<FloatingActionButton size="medium" onClick={handleAdd} />
```

### Responsive Sizing

Icons scale perfectly due to SVG format. Recommended sizes by use case:

- **Navigation bar icons**: 24px
- **App header icons**: 24-32px
- **Floating action button icons**: 24-28px
- **Logo in header**: 32px
- **Logo in splash screen**: 64-128px
- **Streak badge**: 32-48px
- **Compact streak**: 24-32px

---

## Platform Optimization

### Android
- Material Design 3 compliant
- Stroke widths optimized for MDPI, HDPI, XHDPI, XXHDPI, XXXHDPI
- Touch targets meet minimum 48dp requirement
- Safe area insets supported

### iOS
- Human Interface Guidelines compliant
- SF Symbols design language influence
- Optimized for Retina displays (@2x, @3x)
- Safe area insets for notched devices
- Dynamic Type compatible

### Web
- React Native Web compatible
- SVG renders crisp at all zoom levels
- Accessible (semantic HTML when rendered)
- Performance optimized (single SVG per icon)

---

## Accessibility

### Color Contrast

All icon colors meet WCAG AA standards:
- Active blue (#4D8DFF) on dark navy: AAA
- White text on dark navy: AAA
- Badge red (#EF4444) on dark navy: AAA

### Touch Targets

- Minimum touch target: 48x48 dp (Android) / 44x44 pt (iOS)
- Navigation icons: 64px wide clickable area
- FAB: 56px minimum (medium size)

### Semantic Naming

All icons have descriptive names and support aria-label attributes for screen readers.

---

## File Structure

```
src/
  app/
    components/
      icons/
        TimeZapLogo.tsx
        DashboardIcon.tsx
        TasksIcon.tsx
        HabitsIcon.tsx
        CalendarIcon.tsx
        AccountIcon.tsx
        PlusIcon.tsx
        NotificationIcon.tsx
        StreakFlameIcon.tsx
        index.ts
      BottomNavigation.tsx
      FloatingActionButton.tsx
      DashboardMockup.tsx
```

---

## Best Practices

### Performance

1. **Avoid inline SVG duplication**: Import components, don't copy SVG code
2. **Use memo for static icons**: `React.memo(Icon)` for icons that don't change
3. **Lazy load large icon sets**: Only import icons you need per screen

### Consistency

1. **Always use design system icons**: Don't create one-off custom icons
2. **Respect active/inactive states**: Use provided state management
3. **Maintain stroke width**: All custom icons should use 2px strokes
4. **Follow color palette**: Only use defined colors from palette

### Customization

Icons accept `className` prop for additional styling:

```tsx
<DashboardIcon 
  size={24} 
  active={true}
  className="mr-2 custom-class"
/>
```

---

## Version

**Version**: 1.0.0  
**Last Updated**: June 2, 2026  
**Status**: Production Ready

---

## Support

For questions or issues with the TimeZap design system, refer to the component showcase at `/` or review individual component files for prop documentation.

---

**Built with ⚡ by the TimeZap team**
