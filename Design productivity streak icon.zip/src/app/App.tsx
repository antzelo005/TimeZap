import TimeZapLogo from "./components/icons/TimeZapLogo";
import DashboardIcon from "./components/icons/DashboardIcon";
import TasksIcon from "./components/icons/TasksIcon";
import HabitsIcon from "./components/icons/HabitsIcon";
import CalendarIcon from "./components/icons/CalendarIcon";
import AccountIcon from "./components/icons/AccountIcon";
import PlusIcon from "./components/icons/PlusIcon";
import NotificationIcon from "./components/icons/NotificationIcon";
import StreakFlameIcon from "./components/icons/StreakFlameIcon";
import BottomNavigation from "./components/BottomNavigation";
import FloatingActionButton from "./components/FloatingActionButton";
import DashboardMockup from "./components/DashboardMockup";

export default function App() {
  return (
    <div className="size-full overflow-y-auto bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto p-8 space-y-16 pb-24">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-4">
            <TimeZapLogo size={48} />
            <h1 className="text-5xl font-bold text-gray-900">TimeZap</h1>
          </div>
          <p className="text-xl text-gray-600">Complete Professional Icon System & UI Asset Package</p>
          <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
            <span>React Native Optimized</span>
            <span>•</span>
            <span>SVG Vector Format</span>
            <span>•</span>
            <span>Dark Mode First</span>
          </div>
        </div>

        {/* Dashboard Mockup */}
        <section className="space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold text-gray-900">Dashboard UI Concept</h2>
            <p className="text-gray-600">Complete mobile app interface with all design system components</p>
          </div>
          <div className="relative">
            <DashboardMockup />
          </div>
        </section>

        {/* Brand Identity */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">1. Brand Identity</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">TimeZap Logo</h3>
              <div className="flex items-center justify-center gap-8 py-8">
                <div className="bg-[#081A33] p-8 rounded-2xl">
                  <TimeZapLogo size={64} />
                </div>
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl">
                  <TimeZapLogo size={64} />
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Primary Color:</span>
                  <span className="font-mono text-gray-900">#FFC93C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Style:</span>
                  <span className="text-gray-900">Geometric Lightning Bolt</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Format:</span>
                  <span className="text-gray-900">SVG Vector</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">Color Palette</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-[#081A33] border border-gray-200" />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">Dark Navy</p>
                    <p className="font-mono text-sm text-gray-600">#081A33</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-[#4D8DFF] border border-gray-200" />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">Accent Blue</p>
                    <p className="font-mono text-sm text-gray-600">#4D8DFF</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-[#FFC93C] border border-gray-200" />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">Accent Yellow</p>
                    <p className="font-mono text-sm text-gray-600">#FFC93C</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-white border border-gray-200" />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">White</p>
                    <p className="font-mono text-sm text-gray-600">#FFFFFF</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Navigation Icons */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">2. Navigation Icon System</h2>
          <div className="bg-white rounded-2xl p-8 shadow-sm">
            <div className="grid md:grid-cols-5 gap-8">
              {[
                { Icon: DashboardIcon, name: "Dashboard" },
                { Icon: TasksIcon, name: "Tasks" },
                { Icon: HabitsIcon, name: "Habits" },
                { Icon: CalendarIcon, name: "Calendar" },
                { Icon: AccountIcon, name: "Account" },
              ].map(({ Icon, name }) => (
                <div key={name} className="text-center space-y-4">
                  <h4 className="font-semibold text-gray-800">{name}</h4>
                  <div className="space-y-6">
                    <div className="bg-[#081A33] rounded-xl p-6 space-y-2">
                      <Icon size={32} active={false} />
                      <p className="text-xs text-white/60">Inactive</p>
                    </div>
                    <div className="bg-[#081A33] rounded-xl p-6 space-y-2">
                      <Icon size={32} active={true} />
                      <p className="text-xs text-[#4D8DFF]">Active</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Bottom Navigation */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">3. Bottom Navigation System</h2>
          <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <div className="max-w-md mx-auto space-y-4">
              <p className="text-center text-gray-600">Cohesive navigation with consistent states</p>
              <div className="bg-gray-100 rounded-2xl p-4">
                <BottomNavigation activeItem="tasks" />
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>• Consistent 2px stroke width</p>
                <p>• Active state: #4D8DFF (Accent Blue)</p>
                <p>• Inactive state: White with 60% opacity</p>
                <p>• Safe area support for notched devices</p>
                <p>• Optimized height for ergonomic reach</p>
              </div>
            </div>
          </div>
        </section>

        {/* Streak Icon System */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">4. Streak Icon System</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">Badge Style</h3>
              <div className="bg-[#081A33] rounded-xl p-8">
                <div className="flex items-center justify-center gap-6">
                  <div className="text-center space-y-2">
                    <StreakFlameIcon size={48} streakNumber={7} active={true} />
                    <p className="text-xs text-white/60">Active (7 days)</p>
                  </div>
                  <div className="text-center space-y-2">
                    <StreakFlameIcon size={48} streakNumber={0} active={false} />
                    <p className="text-xs text-white/60">Inactive (0 days)</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">Compact Style</h3>
              <div className="bg-[#081A33] rounded-xl p-8">
                <div className="flex items-center justify-center gap-6">
                  <div className="text-center space-y-2">
                    <StreakFlameIcon size={32} streakNumber={12} active={true} compact={true} />
                    <p className="text-xs text-white/60">Active (12 days)</p>
                  </div>
                  <div className="text-center space-y-2">
                    <StreakFlameIcon size={32} streakNumber={0} active={false} compact={true} />
                    <p className="text-xs text-white/60">Inactive (0 days)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <h3 className="text-xl font-semibold text-gray-800">Size Variations</h3>
            <div className="bg-[#081A33] rounded-xl p-8">
              <div className="flex items-end justify-center gap-8">
                {[24, 32, 40, 48, 64].map((size) => (
                  <div key={size} className="text-center space-y-2">
                    <StreakFlameIcon size={size} streakNumber={5} active={true} />
                    <p className="text-xs text-white/60">{size}px</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Action Buttons */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">5. Action Buttons</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">Floating Action Button</h3>
              <div className="bg-gray-100 rounded-xl p-12">
                <div className="flex items-center justify-center gap-8">
                  <div className="text-center space-y-2">
                    <FloatingActionButton size="small" />
                    <p className="text-xs text-gray-600">Small (48px)</p>
                  </div>
                  <div className="text-center space-y-2">
                    <FloatingActionButton size="medium" />
                    <p className="text-xs text-gray-600">Medium (56px)</p>
                  </div>
                  <div className="text-center space-y-2">
                    <FloatingActionButton size="large" />
                    <p className="text-xs text-gray-600">Large (64px)</p>
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>• Background: #4D8DFF (Accent Blue)</p>
                <p>• White plus icon with rounded strokes</p>
                <p>• Elevated shadow for depth</p>
                <p>• Hover and active states</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
              <h3 className="text-xl font-semibold text-gray-800">Plus Icon</h3>
              <div className="bg-[#4D8DFF] rounded-xl p-12">
                <div className="flex items-center justify-center gap-8">
                  {[16, 24, 32, 48].map((size) => (
                    <div key={size} className="text-center space-y-2">
                      <PlusIcon size={size} />
                      <p className="text-xs text-white/60">{size}px</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>• 3px stroke width for visibility</p>
                <p>• Rounded caps for friendly appearance</p>
                <p>• Perfect centering</p>
                <p>• Scalable to any size</p>
              </div>
            </div>
          </div>
        </section>

        {/* Notification System */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">6. Notification System</h2>
          <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <h3 className="text-xl font-semibold text-gray-800">Notification Bell with Badge</h3>
            <div className="bg-[#081A33] rounded-xl p-12">
              <div className="flex items-center justify-center gap-12">
                <div className="text-center space-y-3">
                  <NotificationIcon size={32} />
                  <p className="text-xs text-white/60">No notifications</p>
                </div>
                <div className="text-center space-y-3">
                  <NotificationIcon size={32} badgeCount={1} />
                  <p className="text-xs text-white/60">1 notification</p>
                </div>
                <div className="text-center space-y-3">
                  <NotificationIcon size={32} badgeCount={9} />
                  <p className="text-xs text-white/60">9 notifications</p>
                </div>
                <div className="text-center space-y-3">
                  <NotificationIcon size={32} badgeCount={99} />
                  <p className="text-xs text-white/60">99 notifications</p>
                </div>
                <div className="text-center space-y-3">
                  <NotificationIcon size={32} badgeCount={150} />
                  <p className="text-xs text-white/60">99+ notifications</p>
                </div>
              </div>
            </div>
            <div className="text-sm text-gray-600 space-y-1">
              <p>• White bell icon optimized for dark backgrounds</p>
              <p>• Red notification badge (#EF4444)</p>
              <p>• Supports 1-99, displays "99+" for higher values</p>
              <p>• Clean professional appearance</p>
            </div>
          </div>
        </section>

        {/* Design System Specifications */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">7. Design System Specifications</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">Icon Guidelines</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Base Size:</span>
                  <span className="font-semibold text-gray-900">24x24 px</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Stroke Width:</span>
                  <span className="font-semibold text-gray-900">2px</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Corner Radius:</span>
                  <span className="font-semibold text-gray-900">Rounded</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Active Color:</span>
                  <span className="font-mono text-gray-900">#4D8DFF</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Inactive Opacity:</span>
                  <span className="font-semibold text-gray-900">60%</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="text-gray-600">Format:</span>
                  <span className="font-semibold text-gray-900">SVG Vector</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm space-y-4">
              <h3 className="text-xl font-semibold text-gray-800">Platform Optimization</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="font-semibold text-gray-900">Android Optimized</p>
                    <p className="text-gray-600">Material Design 3 compliant</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="font-semibold text-gray-900">iOS Optimized</p>
                    <p className="text-gray-600">Human Interface Guidelines</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="font-semibold text-gray-900">Web Optimized</p>
                    <p className="text-gray-600">React Native Web compatible</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-green-500 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="font-semibold text-gray-900">Dark Mode First</p>
                    <p className="text-gray-600">Designed for #081A33 background</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Usage Examples */}
        <section className="space-y-6">
          <h2 className="text-3xl font-bold text-gray-900">8. Usage Examples</h2>
          <div className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <h3 className="text-xl font-semibold text-gray-800">React Native Component Import</h3>
            <div className="bg-gray-900 rounded-xl p-6 overflow-x-auto">
              <pre className="text-sm text-gray-100 font-mono">
{`import DashboardIcon from './icons/DashboardIcon';
import TasksIcon from './icons/TasksIcon';
import StreakFlameIcon from './icons/StreakFlameIcon';
import FloatingActionButton from './FloatingActionButton';

// Usage
<DashboardIcon size={24} active={true} />
<TasksIcon size={24} active={false} />
<StreakFlameIcon size={32} streakNumber={12} active={true} />
<FloatingActionButton size="medium" onClick={handleAdd} />`}
              </pre>
            </div>
          </div>
        </section>

        {/* Footer */}
        <div className="text-center space-y-4 pt-8 border-t border-gray-200">
          <div className="flex items-center justify-center gap-4">
            <TimeZapLogo size={32} />
            <p className="text-2xl font-bold text-gray-900">TimeZap Design System</p>
          </div>
          <p className="text-gray-600">Professional Icon System & UI Asset Package</p>
          <p className="text-sm text-gray-500">Production-ready • SVG Vector • React Native Optimized</p>
        </div>
      </div>
    </div>
  );
}