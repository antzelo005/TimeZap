import { useState } from "react";
import DashboardIcon from "./icons/DashboardIcon";
import TasksIcon from "./icons/TasksIcon";
import HabitsIcon from "./icons/HabitsIcon";
import CalendarIcon from "./icons/CalendarIcon";
import AccountIcon from "./icons/AccountIcon";

type NavItem = "dashboard" | "tasks" | "habits" | "calendar" | "account";

interface BottomNavigationProps {
  activeItem?: NavItem;
  onItemClick?: (item: NavItem) => void;
  className?: string;
}

export default function BottomNavigation({
  activeItem: controlledActiveItem,
  onItemClick,
  className = ""
}: BottomNavigationProps) {
  const [internalActiveItem, setInternalActiveItem] = useState<NavItem>("dashboard");

  const activeItem = controlledActiveItem ?? internalActiveItem;

  const handleItemClick = (item: NavItem) => {
    if (onItemClick) {
      onItemClick(item);
    } else {
      setInternalActiveItem(item);
    }
  };

  const navItems: Array<{ id: NavItem; label: string; Icon: typeof DashboardIcon }> = [
    { id: "dashboard", label: "Dashboard", Icon: DashboardIcon },
    { id: "tasks", label: "Tasks", Icon: TasksIcon },
    { id: "habits", label: "Habits", Icon: HabitsIcon },
    { id: "calendar", label: "Calendar", Icon: CalendarIcon },
    { id: "account", label: "Account", Icon: AccountIcon },
  ];

  return (
    <nav
      className={`bg-[#081A33] border-t border-white/10 ${className}`}
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      <div className="flex justify-around items-center h-20 px-4">
        {navItems.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => handleItemClick(id)}
            className="flex flex-col items-center gap-1 min-w-[64px] transition-all"
          >
            <Icon size={24} active={activeItem === id} />
            <span
              className={`text-xs transition-all ${
                activeItem === id
                  ? "text-[#4D8DFF] font-medium"
                  : "text-white/60"
              }`}
            >
              {label}
            </span>
          </button>
        ))}
      </div>
    </nav>
  );
}
