import StreakFlameIcon from "./icons/StreakFlameIcon";
import NotificationIcon from "./icons/NotificationIcon";
import TimeZapLogo from "./icons/TimeZapLogo";
import BottomNavigation from "./BottomNavigation";
import FloatingActionButton from "./FloatingActionButton";

export default function DashboardMockup() {
  return (
    <div className="bg-[#081A33] rounded-3xl overflow-hidden shadow-2xl w-full max-w-sm mx-auto">
      {/* Status Bar */}
      <div className="bg-black/20 px-6 py-3 flex justify-between items-center text-white text-xs">
        <span>9:41</span>
        <div className="flex gap-1">
          <div className="w-4 h-3 border border-white/50 rounded-sm" />
          <div className="w-4 h-3 border border-white/50 rounded-sm" />
          <div className="w-4 h-3 border border-white/50 rounded-sm" />
        </div>
      </div>

      {/* App Header */}
      <div className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <TimeZapLogo size={32} />
          <h1 className="text-white text-xl font-semibold">TimeZap</h1>
        </div>
        <div className="flex items-center gap-4">
          <StreakFlameIcon size={24} streakNumber={12} active={true} compact={true} />
          <NotificationIcon size={24} badgeCount={3} />
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 pb-6 space-y-4">
        {/* Greeting */}
        <div className="pt-2">
          <p className="text-white/60 text-sm">Good morning</p>
          <h2 className="text-white text-2xl font-semibold">Ready to be productive?</h2>
        </div>

        {/* Task Summary Card */}
        <button className="w-full bg-white/5 hover:bg-white/10 backdrop-blur-sm border border-white/10 rounded-2xl p-5 text-left transition-all">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium text-lg">Today's Tasks</h3>
            <div className="w-10 h-10 bg-[#4D8DFF]/20 rounded-full flex items-center justify-center">
              <span className="text-[#4D8DFF] font-bold text-lg">5</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-white/60">Progress</span>
                <span className="text-white font-medium">3/5 completed</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div className="bg-[#4D8DFF] h-2 rounded-full" style={{ width: '60%' }} />
              </div>
            </div>
          </div>
        </button>

        {/* Habit Summary Card */}
        <button className="w-full bg-white/5 hover:bg-white/10 backdrop-blur-sm border border-white/10 rounded-2xl p-5 text-left transition-all">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium text-lg">Today's Habits</h3>
            <div className="w-10 h-10 bg-[#FFC93C]/20 rounded-full flex items-center justify-center">
              <span className="text-[#FFC93C] font-bold text-lg">4</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-white/60">Progress</span>
                <span className="text-white font-medium">2/4 completed</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div className="bg-[#FFC93C] h-2 rounded-full" style={{ width: '50%' }} />
              </div>
            </div>
          </div>
        </button>

        {/* Weekly Progress */}
        <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-5">
          <h3 className="text-white font-medium text-lg mb-4">This Week</h3>
          <div className="flex justify-between gap-2">
            {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => {
              const completed = index < 4;
              const isToday = index === 3;
              return (
                <button
                  key={index}
                  className={`
                    flex-1 aspect-square rounded-xl flex flex-col items-center justify-center gap-1 transition-all
                    ${completed ? 'bg-[#4D8DFF] text-white' : 'bg-white/5 text-white/40 hover:bg-white/10'}
                    ${isToday ? 'ring-2 ring-[#FFC93C]' : ''}
                  `}
                >
                  <span className="text-xs font-medium">{day}</span>
                  {completed && (
                    <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none">
                      <path d="M2 6L5 9L10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="absolute bottom-24 right-6">
        <FloatingActionButton size="medium" />
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation activeItem="dashboard" />
    </div>
  );
}
