interface PlusIconProps {
  size?: number;
  className?: string;
}

export default function PlusIcon({ size = 24, className = "" }: PlusIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Vertical line */}
      <line
        x1="12"
        y1="5"
        x2="12"
        y2="19"
        stroke="white"
        strokeWidth="3"
        strokeLinecap="round"
      />
      {/* Horizontal line */}
      <line
        x1="5"
        y1="12"
        x2="19"
        y2="12"
        stroke="white"
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  );
}
