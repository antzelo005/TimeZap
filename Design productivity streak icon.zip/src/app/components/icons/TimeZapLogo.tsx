interface TimeZapLogoProps {
  size?: number;
  className?: string;
}

export default function TimeZapLogo({ size = 32, className = "" }: TimeZapLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Geometric lightning bolt - stylized Z shape */}
      <path
        d="M20 3L8 17H16L12 29L24 15H16L20 3Z"
        fill="#FFC93C"
      />
      {/* Accent highlight */}
      <path
        d="M20 3L8 17H13L17 11L20 3Z"
        fill="#FFD700"
        opacity="0.6"
      />
    </svg>
  );
}
