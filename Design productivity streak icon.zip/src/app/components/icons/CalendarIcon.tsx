interface CalendarIconProps {
  size?: number;
  active?: boolean;
  className?: string;
}

export default function CalendarIcon({
  size = 24,
  active = false,
  className = ""
}: CalendarIconProps) {
  const color = active ? "#4D8DFF" : "#FFFFFF";
  const opacity = active ? "1" : "0.6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Calendar outline */}
      <rect
        x="3"
        y="5"
        width="18"
        height="16"
        rx="2"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      {/* Top bar */}
      <line
        x1="3"
        y1="9"
        x2="21"
        y2="9"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      {/* Hangers */}
      <line
        x1="7"
        y1="3"
        x2="7"
        y2="7"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      <line
        x1="17"
        y1="3"
        x2="17"
        y2="7"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      {/* Date dots */}
      <circle cx="7" cy="14" r="1" fill={color} opacity={opacity} />
      <circle cx="12" cy="14" r="1" fill={color} opacity={opacity} />
      <circle cx="17" cy="14" r="1" fill={color} opacity={opacity} />
    </svg>
  );
}
