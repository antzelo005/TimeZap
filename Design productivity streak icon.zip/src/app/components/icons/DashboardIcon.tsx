interface DashboardIconProps {
  size?: number;
  active?: boolean;
  className?: string;
}

export default function DashboardIcon({
  size = 24,
  active = false,
  className = ""
}: DashboardIconProps) {
  const color = active ? "#4D8DFF" : "#FFFFFF";
  const opacity = active ? "1" : "0.6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Analytics bars */}
      <rect
        x="3"
        y="14"
        width="4"
        height="7"
        rx="1"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      <rect
        x="10"
        y="8"
        width="4"
        height="13"
        rx="1"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      <rect
        x="17"
        y="3"
        width="4"
        height="18"
        rx="1"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
    </svg>
  );
}
