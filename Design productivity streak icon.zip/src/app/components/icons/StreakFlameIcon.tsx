interface StreakFlameIconProps {
  size?: number;
  streakNumber?: number;
  active?: boolean;
  compact?: boolean;
  className?: string;
}

export default function StreakFlameIcon({
  size = 32,
  streakNumber,
  active = true,
  compact = false,
  className = ""
}: StreakFlameIconProps) {
  return (
    <div className={`relative inline-flex items-center gap-1 ${className}`}>
      {compact ? (
        // Compact version - icon with number beside it
        <>
          <svg
            width={size}
            height={size}
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Flame shape */}
            <path
              d="M12 3C11.5 4.5 10 6 10 8C10 8.5 10.2 9 10.5 9.4C10.1 9.1 9.8 8.7 9.8 8.2C9.8 7.5 10 6.8 10 6C8.5 7.5 7.5 9 7.5 11C7.5 13.5 9.5 15.5 12 15.5C14.5 15.5 16.5 13.5 16.5 11C16.5 8.5 15 6.5 14 5.5C14 6.5 13.8 7.2 13.3 7.8C13.5 7.3 13.6 6.8 13.6 6.3C13.6 5 13 4 12 3Z"
              fill={active ? "url(#flameGradient)" : "#6B7280"}
            />
            {/* Lightning bolt */}
            {active && (
              <path
                d="M12.5 7L10.5 10.5H12L11.5 13L13.5 9.5H12L12.5 7Z"
                fill="white"
              />
            )}
            <defs>
              <linearGradient
                id="flameGradient"
                x1="12"
                y1="3"
                x2="12"
                y2="15.5"
                gradientUnits="userSpaceOnUse"
              >
                <stop offset="0%" stopColor="#FFD700" />
                <stop offset="50%" stopColor="#FFA500" />
                <stop offset="100%" stopColor="#FF6B00" />
              </linearGradient>
            </defs>
          </svg>
          {streakNumber !== undefined && (
            <span className={`font-bold text-sm ${active ? 'text-white' : 'text-gray-500'}`}>
              {streakNumber}
            </span>
          )}
        </>
      ) : (
        // Badge version - circular with number inside
        <>
          <svg
            width={size}
            height={size}
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Background circle */}
            <circle cx="16" cy="16" r="16" fill="#081A33" />

            {/* Flame shape - scaled for larger canvas */}
            <path
              d="M16 6C15.3 8 13.3 10.7 13.3 13.3C13.3 14 13.6 14.7 14 15.2C13.5 14.8 13.1 14.2 13.1 13.6C13.1 12.7 13.3 11.7 13.3 10.7C11.3 12.7 10 14.7 10 17.3C10 20.7 12.7 23.3 16 23.3C19.3 23.3 22 20.7 22 17.3C22 14 20 11.3 18.7 10C18.7 11.3 18.4 12.3 17.7 13.1C18 12.4 18.1 11.7 18.1 11.1C18.1 9.3 17.3 7.3 16 6Z"
              fill={active ? "url(#flameBadgeGradient)" : "#6B7280"}
            />

            {/* Lightning bolt */}
            {active && (
              <path
                d="M16.7 11L13.7 16H15.7L14.7 21L18.7 15H16.7L16.7 11Z"
                fill="white"
              />
            )}

            <defs>
              <linearGradient
                id="flameBadgeGradient"
                x1="16"
                y1="6"
                x2="16"
                y2="23.3"
                gradientUnits="userSpaceOnUse"
              >
                <stop offset="0%" stopColor="#FFD700" />
                <stop offset="50%" stopColor="#FFA500" />
                <stop offset="100%" stopColor="#FF6B00" />
              </linearGradient>
            </defs>
          </svg>

          {/* Streak number overlay */}
          {streakNumber !== undefined && (
            <div className="absolute inset-0 flex items-center justify-center">
              <span
                className={`font-bold ${active ? 'text-white' : 'text-gray-600'}`}
                style={{
                  fontSize: size * 0.35,
                  textShadow: active ? '0 1px 2px rgba(0,0,0,0.3)' : 'none'
                }}
              >
                {streakNumber}
              </span>
            </div>
          )}
        </>
      )}
    </div>
  );
}
