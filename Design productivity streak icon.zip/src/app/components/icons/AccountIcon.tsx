interface AccountIconProps {
  size?: number;
  active?: boolean;
  className?: string;
}

export default function AccountIcon({
  size = 24,
  active = false,
  className = ""
}: AccountIconProps) {
  const color = active ? "#4D8DFF" : "#FFFFFF";
  const opacity = active ? "1" : "0.6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Head */}
      <circle
        cx="12"
        cy="8"
        r="4"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      {/* Body */}
      <path
        d="M5 20C5 16.134 8.134 13 12 13C15.866 13 19 16.134 19 20"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
    </svg>
  );
}
