interface HabitsIconProps {
  size?: number;
  active?: boolean;
  className?: string;
}

export default function HabitsIcon({
  size = 24,
  active = false,
  className = ""
}: HabitsIconProps) {
  const color = active ? "#4D8DFF" : "#FFFFFF";
  const opacity = active ? "1" : "0.6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Circular arrows representing repetition */}
      <path
        d="M4 12C4 7.58172 7.58172 4 12 4C14.5 4 16.7 5.1 18.2 6.8"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      <path
        d="M20 12C20 16.4183 16.4183 20 12 20C9.5 20 7.3 18.9 5.8 17.2"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      {/* Arrow tips */}
      <path
        d="M18.2 6.8L17 4L20 4.5"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={opacity}
      />
      <path
        d="M5.8 17.2L7 20L4 19.5"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={opacity}
      />
    </svg>
  );
}
