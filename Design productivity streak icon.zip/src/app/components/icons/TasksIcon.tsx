interface TasksIconProps {
  size?: number;
  active?: boolean;
  className?: string;
}

export default function TasksIcon({
  size = 24,
  active = false,
  className = ""
}: TasksIconProps) {
  const color = active ? "#4D8DFF" : "#FFFFFF";
  const opacity = active ? "1" : "0.6";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Checklist items */}
      <circle
        cx="6"
        cy="6"
        r="1.5"
        fill={color}
        opacity={opacity}
      />
      <line
        x1="10"
        y1="6"
        x2="20"
        y2="6"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      <circle
        cx="6"
        cy="12"
        r="1.5"
        fill={color}
        opacity={opacity}
      />
      <line
        x1="10"
        y1="12"
        x2="20"
        y2="12"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
      <circle
        cx="6"
        cy="18"
        r="1.5"
        stroke={color}
        strokeWidth="2"
        opacity={opacity}
      />
      <line
        x1="10"
        y1="18"
        x2="20"
        y2="18"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        opacity={opacity}
      />
    </svg>
  );
}
