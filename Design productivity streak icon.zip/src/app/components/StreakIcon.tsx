interface StreakIconProps {
  size?: number;
  streakNumber?: number;
  className?: string;
}

export default function StreakIcon({
  size = 24,
  streakNumber,
  className = ""
}: StreakIconProps) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Dark navy circular background */}
        <circle cx="12" cy="12" r="12" fill="#081A33" />

        {/* Flame shape - yellow/orange gradient */}
        <path
          d="M12 5C11.5 6.5 10 8 10 10C10 10.5 10.2 11 10.5 11.4C10.1 11.1 9.8 10.7 9.8 10.2C9.8 9.5 10 8.8 10 8C8.5 9.5 7.5 11 7.5 13C7.5 15.5 9.5 17.5 12 17.5C14.5 17.5 16.5 15.5 16.5 13C16.5 10.5 15 8.5 14 7.5C14 8.5 13.8 9.2 13.3 9.8C13.5 9.3 13.6 8.8 13.6 8.3C13.6 7 13 6 12 5Z"
          fill="url(#flameGradient)"
        />

        {/* Lightning bolt - white */}
        <path
          d="M12.5 9L10.5 12.5H12L11.5 15L13.5 11.5H12L12.5 9Z"
          fill="white"
        />

        {/* Gradient definition */}
        <defs>
          <linearGradient
            id="flameGradient"
            x1="12"
            y1="5"
            x2="12"
            y2="17.5"
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="50%" stopColor="#FFA500" />
            <stop offset="100%" stopColor="#FF6B00" />
          </linearGradient>
        </defs>
      </svg>

      {/* Streak number overlay */}
      {streakNumber !== undefined && (
        <div className="absolute inset-0 flex items-center justify-center">
          <span
            className="font-bold text-white"
            style={{
              fontSize: size * 0.35,
              textShadow: '0 1px 2px rgba(0,0,0,0.3)'
            }}
          >
            {streakNumber}
          </span>
        </div>
      )}
    </div>
  );
}
