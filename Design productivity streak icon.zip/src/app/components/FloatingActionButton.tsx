import PlusIcon from "./icons/PlusIcon";

interface FloatingActionButtonProps {
  onClick?: () => void;
  size?: "small" | "medium" | "large";
  className?: string;
}

export default function FloatingActionButton({
  onClick,
  size = "medium",
  className = ""
}: FloatingActionButtonProps) {
  const sizeClasses = {
    small: "w-12 h-12",
    medium: "w-14 h-14",
    large: "w-16 h-16"
  };

  const iconSizes = {
    small: 20,
    medium: 24,
    large: 28
  };

  return (
    <button
      onClick={onClick}
      className={`
        ${sizeClasses[size]}
        bg-[#4D8DFF]
        rounded-full
        flex
        items-center
        justify-center
        shadow-lg
        hover:bg-[#3D7DFF]
        active:bg-[#2D6DFF]
        transition-all
        hover:shadow-xl
        active:scale-95
        ${className}
      `}
      aria-label="Add new item"
    >
      <PlusIcon size={iconSizes[size]} />
    </button>
  );
}
