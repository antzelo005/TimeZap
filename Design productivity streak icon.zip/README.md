
  # Design productivity streak icon

  This is a code bundle for Design productivity streak icon. The original project is available at https://www.figma.com/design/715hd2k5VpFPpFRzgM4gYU/Design-productivity-streak-icon.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  